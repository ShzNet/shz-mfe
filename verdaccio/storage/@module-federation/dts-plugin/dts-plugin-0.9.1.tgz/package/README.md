# @module-federation/dts-plugin
