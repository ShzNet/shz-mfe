# `@module-federation/managers` Documentation
