# `@module-federation/rspack` Documentation
