export { signalToCode } from 'nx/src/devkit-internals';
//# sourceMappingURL=internal.d.ts.map