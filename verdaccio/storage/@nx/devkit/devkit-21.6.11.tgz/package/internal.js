"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.signalToCode = void 0;
var devkit_internals_1 = require("nx/src/devkit-internals");
Object.defineProperty(exports, "signalToCode", { enumerable: true, get: function () { return devkit_internals_1.signalToCode; } });
