"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatFiles = formatFiles;
const devkit_exports_1 = require("nx/src/devkit-exports");
const devkit_internals_1 = require("nx/src/devkit-internals");
const path = require("path");
/**
 * Formats all the created or updated files using Prettier
 * @param tree - the file system tree
 * @param options - options for the formatFiles function
 */
async function formatFiles(tree, options = {}) {
    let prettier;
    try {
        prettier = await Promise.resolve().then(() => require('prettier'));
        /**
         * Even after we discovered prettier in node_modules, we need to be sure that the user is intentionally using prettier
         * before proceeding to format with it.
         */
        if (!(0, devkit_internals_1.isUsingPrettierInTree)(tree)) {
            return;
        }
    }
    catch { }
    /**
     * TODO(v22): Stop sorting tsconfig paths by default, paths are now less common/important
     * in Nx workspace setups, and the sorting causes comments to be lost.
     */
    options.sortRootTsconfigPaths ??=
        process.env.NX_FORMAT_SORT_TSCONFIG_PATHS !== 'false';
    if (options.sortRootTsconfigPaths) {
        sortTsConfig(tree);
    }
    if (!prettier)
        return;
    const files = new Set(tree.listChanges().filter((file) => file.type !== 'DELETE'));
    const changedPrettierInTree = getChangedPrettierConfigInTree(tree);
    await Promise.all(Array.from(files).map(async (file) => {
        try {
            const systemPath = path.join(tree.root, file.path);
            const resolvedOptions = await prettier.resolveConfig(systemPath, {
                editorconfig: true,
            });
            const options = {
                ...resolvedOptions,
                ...changedPrettierInTree,
                filepath: systemPath,
            };
            if (file.path.endsWith('.swcrc')) {
                options.parser = 'json';
            }
            const support = await prettier.getFileInfo(systemPath, options);
            if (support.ignored || !support.inferredParser) {
                return;
            }
            tree.write(file.path, 
            // In prettier v3 the format result is a promise
            await prettier.format(file.content.toString('utf-8'), options));
        }
        catch (e) {
            console.warn(`Could not format ${file.path}. Error: "${e.message}"`);
        }
    }));
}
function sortTsConfig(tree) {
    try {
        const tsConfigPath = getRootTsConfigPath(tree);
        if (!tsConfigPath) {
            return;
        }
        const tsconfig = (0, devkit_exports_1.readJson)(tree, tsConfigPath);
        if (!tsconfig.compilerOptions?.paths) {
            // no paths to sort
            return;
        }
        (0, devkit_exports_1.writeJson)(tree, tsConfigPath, {
            ...tsconfig,
            compilerOptions: {
                ...tsconfig.compilerOptions,
                paths: (0, devkit_internals_1.sortObjectByKeys)(tsconfig.compilerOptions.paths),
            },
        });
    }
    catch (e) {
        // catch noop
    }
}
function getRootTsConfigPath(tree) {
    for (const path of ['tsconfig.base.json', 'tsconfig.json']) {
        if (tree.exists(path)) {
            return path;
        }
    }
    return null;
}
function getChangedPrettierConfigInTree(tree) {
    if (tree.listChanges().find((file) => file.path === '.prettierrc')) {
        try {
            return (0, devkit_exports_1.readJson)(tree, '.prettierrc');
        }
        catch {
            return null;
        }
    }
    else {
        return null;
    }
}
