export declare function checkAndCleanWithSemver(pkgName: string, version: string): string;
//# sourceMappingURL=semver.d.ts.map