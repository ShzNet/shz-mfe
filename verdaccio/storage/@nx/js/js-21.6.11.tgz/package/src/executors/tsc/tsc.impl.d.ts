import { ExecutorContext } from '@nx/devkit';
import type { TypeScriptCompilationOptions } from '@nx/workspace/src/utilities/typescript/compilation';
import { ExecutorOptions, NormalizedExecutorOptions } from '../../utils/schema';
export declare function determineModuleFormatFromTsConfig(absolutePathToTsConfig: string): 'cjs' | 'esm';
export declare function createTypeScriptCompilationOptions(normalizedOptions: NormalizedExecutorOptions, context: ExecutorContext): TypeScriptCompilationOptions;
export declare function tscExecutor(_options: ExecutorOptions, context: ExecutorContext): AsyncGenerator<import("../../utils/typescript/compile-typescript-files").TypescriptCompilationResult, any, any>;
export default tscExecutor;
//# sourceMappingURL=tsc.impl.d.ts.map