export declare function resolveVersionSpec(name: string, version: string, spec: string, location?: string): string;
//# sourceMappingURL=resolve-version-spec.d.ts.map