import { ProjectGraph, ProjectGraphProjectNode } from '@nx/devkit';
export declare function sortProjectsTopologically(projectGraph: ProjectGraph, projectNodes: ProjectGraphProjectNode[]): ProjectGraphProjectNode[];
//# sourceMappingURL=sort-projects-topologically.d.ts.map