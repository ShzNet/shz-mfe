export interface SyncSchema {}
