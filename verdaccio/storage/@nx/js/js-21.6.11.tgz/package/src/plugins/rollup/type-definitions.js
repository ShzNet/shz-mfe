"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeDefinitions = typeDefinitions;
const path_1 = require("path");
const devkit_1 = require("@nx/devkit");
//NOTE: This is here so we can share between `@nx/rollup` and `@nx/vite`.
/*
 * This plugin takes all entry-points from the generated bundle and creates a
 * bundled version of corresponding d.ts files.
 *
 * For example, `src/index.ts` generates two corresponding files:
 * - `dist/xyz/index.js`
 * - `dist/xyz/src/index.d.ts`
 *
 * We want a third file: `dist/index.d.ts` that re-exports from `src/index.d.ts`.
 * That way, when TSC or IDEs look for types, it will find them in the right place.
 */
function typeDefinitions(options) {
    return {
        name: 'dts-bundle',
        async generateBundle(_opts, bundle) {
            for (const [name, file] of Object.entries(bundle)) {
                if (file.type === 'asset' ||
                    !file.isEntry ||
                    file.facadeModuleId == null) {
                    continue;
                }
                const hasDefaultExport = file.exports.includes('default');
                const entrySourceFileName = (0, path_1.relative)(options.projectRoot, file.facadeModuleId);
                const entrySourceDtsName = entrySourceFileName.replace(/\.[cm]?[jt]sx?$/, '');
                // Replace various JavaScript file extensions (e.g., .js, .cjs, .mjs, .cjs.js, .mjs.js) with .d.ts for generating type definition file names.
                // This regex matches the pattern used in packages/rollup/src/plugins/package-json/update-package-json.ts
                const dtsFileName = file.fileName.replace(/(\.cjs|\.mjs|\.esm\.js|\.cjs\.js|\.mjs\.js|\.js)$/, '.d.ts');
                const relativeSourceDtsName = JSON.stringify('./' + entrySourceDtsName);
                const dtsFileSource = hasDefaultExport
                    ? (0, devkit_1.stripIndents) `
              export * from ${relativeSourceDtsName};
              export { default } from ${relativeSourceDtsName};
            `
                    : `export * from ${relativeSourceDtsName};\n`;
                this.emitFile({
                    type: 'asset',
                    fileName: dtsFileName,
                    source: dtsFileSource,
                });
            }
        },
    };
}
