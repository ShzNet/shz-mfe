import type { InlineProjectGraph } from '../inline';
export declare function generateTmpSwcrc(inlineProjectGraph: InlineProjectGraph, swcrcPath: string, tmpSwcrcPath: string): string;
//# sourceMappingURL=inline.d.ts.map