export declare const nxVersion: any;
export declare const esbuildVersion = "^0.19.2";
export declare const prettierVersion = "^2.6.2";
export declare const swcCliVersion = "~0.6.0";
export declare const swcCoreVersion = "~1.5.7";
export declare const swcHelpersVersion = "~0.5.11";
export declare const swcNodeVersion = "~1.9.1";
export declare const tsLibVersion = "^2.3.0";
export declare const typesNodeVersion = "20.19.9";
export declare const verdaccioVersion = "^6.0.5";
export declare const typescriptVersion = "~5.9.2";
/**
 * The minimum version is currently determined from the lowest version
 * that's supported by the lowest Angular supported version, e.g.
 * `npm view @angular/compiler-cli@18.0.0 peerDependencies.typescript`
 */
export declare const supportedTypescriptVersions = ">=5.4.0";
//# sourceMappingURL=versions.d.ts.map