"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supportedTypescriptVersions = exports.typescriptVersion = exports.verdaccioVersion = exports.typesNodeVersion = exports.tsLibVersion = exports.swcNodeVersion = exports.swcHelpersVersion = exports.swcCoreVersion = exports.swcCliVersion = exports.prettierVersion = exports.esbuildVersion = exports.nxVersion = void 0;
exports.nxVersion = require('../../package.json').version;
exports.esbuildVersion = '^0.19.2';
exports.prettierVersion = '^2.6.2';
exports.swcCliVersion = '~0.6.0';
exports.swcCoreVersion = '~1.5.7';
exports.swcHelpersVersion = '~0.5.11';
exports.swcNodeVersion = '~1.9.1';
exports.tsLibVersion = '^2.3.0';
exports.typesNodeVersion = '20.19.9';
exports.verdaccioVersion = '^6.0.5';
// Typescript
exports.typescriptVersion = '~5.9.2';
/**
 * The minimum version is currently determined from the lowest version
 * that's supported by the lowest Angular supported version, e.g.
 * `npm view @angular/compiler-cli@18.0.0 peerDependencies.typescript`
 */
exports.supportedTypescriptVersions = '>=5.4.0';
