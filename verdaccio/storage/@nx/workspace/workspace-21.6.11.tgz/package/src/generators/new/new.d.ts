import { Tree } from '@nx/devkit';
import { Linter, LinterType } from '../../utils/lint';
import { Agent } from 'nx/src/ai/utils';
interface Schema {
    directory: string;
    name: string;
    appName?: string;
    skipInstall?: boolean;
    style?: string;
    preset: string;
    defaultBase: string;
    framework?: string;
    docker?: boolean;
    js?: boolean;
    nextAppDir?: boolean;
    nextSrcDir?: boolean;
    linter?: Linter | LinterType;
    bundler?: string;
    standaloneApi?: boolean;
    routing?: boolean;
    useReactRouter?: boolean;
    packageManager?: string;
    unitTestRunner?: string;
    e2eTestRunner?: string;
    ssr?: boolean;
    prefix?: string;
    useGitHub?: boolean;
    nxCloud?: 'yes' | 'skip' | 'circleci' | 'github';
    formatter?: string;
    workspaces?: boolean;
    workspaceGlobs?: string | string[];
    useProjectJson?: boolean;
    aiAgents?: Agent[] | Agent;
}
export interface NormalizedSchema extends Schema {
    presetVersion?: string;
    isCustomPreset: boolean;
    nxCloudToken?: string;
    workspaceGlobs?: string[];
    aiAgents?: Agent[];
}
export declare function newGenerator(tree: Tree, opts: Schema): Promise<() => Promise<void>>;
export default newGenerator;
//# sourceMappingURL=new.d.ts.map