import type { Tree } from '@nx/devkit';
export declare function findRootJestConfig(tree: Tree): string | null;
//# sourceMappingURL=jest-config.d.ts.map