export declare const nxVersion: any;
export declare const typescriptVersion = "~5.9.2";
export declare const angularCliVersion = "~20.3.0";
//# sourceMappingURL=versions.d.ts.map