"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.angularCliVersion = exports.typescriptVersion = exports.nxVersion = void 0;
exports.nxVersion = require('../../package.json').version;
exports.typescriptVersion = '~5.9.2';
// TODO: remove when preset generation is reworked and
// deps are not installed from workspace
exports.angularCliVersion = '~20.3.0';
