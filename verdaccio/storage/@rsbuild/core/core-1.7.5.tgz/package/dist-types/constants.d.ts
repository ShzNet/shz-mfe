export declare const __filename: string;
export declare const __dirname: string;
export declare const isDeno: boolean;
export declare const isWindows: boolean;
export declare const ROOT_DIST_DIR = "dist";
export declare const HTML_DIST_DIR = "./";
export declare const FAVICON_DIST_DIR = "./";
export declare const JS_DIST_DIR = "static/js";
export declare const CSS_DIST_DIR = "static/css";
export declare const SVG_DIST_DIR = "static/svg";
export declare const FONT_DIST_DIR = "static/font";
export declare const WASM_DIST_DIR = "static/wasm";
export declare const IMAGE_DIST_DIR = "static/image";
export declare const MEDIA_DIST_DIR = "static/media";
export declare const ASSETS_DIST_DIR = "static/assets";
export declare const LOADER_PATH: string;
export declare const STATIC_PATH: string;
export declare const CLIENT_PATH: string;
export declare const COMPILED_PATH: string;
export declare const TS_CONFIG_FILE = "tsconfig.json";
export declare const HMR_SOCKET_PATH = "/rsbuild-hmr";
export declare const RSBUILD_OUTPUTS_PATH = ".rsbuild";
export declare const DEFAULT_PORT = 3000;
export declare const DEFAULT_DATA_URL_SIZE = 4096;
export declare const DEFAULT_MOUNT_ID = "root";
export declare const DEFAULT_DEV_HOST = "0.0.0.0";
export declare const DEFAULT_ASSET_PREFIX = "/";
export declare const DEFAULT_STACK_TRACE = "summary";
export declare const DEFAULT_WEB_BROWSERSLIST: string[];
export declare const DEFAULT_BROWSERSLIST: Record<string, string[]>;
export declare const JS_REGEX: RegExp;
export declare const SCRIPT_REGEX: RegExp;
export declare const CSS_REGEX: RegExp;
/**
 * Regular expression to match the 'raw' query parameter.
 * Matches patterns like: `?raw`, `?raw&other=value`, `?other=value&raw`, `?raw=value`
 */
export declare const RAW_QUERY_REGEX: RegExp;
/**
 * Regular expression to match the 'inline' query parameter.
 * Matches patterns like: `?inline`, `?inline&other=value`, `?other=value&inline`, `?inline=value`
 */
export declare const INLINE_QUERY_REGEX: RegExp;
export declare const NODE_MODULES_REGEX: RegExp;
export declare const PLUGIN_SWC_NAME = "rsbuild:swc";
export declare const PLUGIN_CSS_NAME = "rsbuild:css";
export declare const FONT_EXTENSIONS: string[];
export declare const IMAGE_EXTENSIONS: string[];
export declare const VIDEO_EXTENSIONS: string[];
export declare const AUDIO_EXTENSIONS: string[];
export declare const LAZY_COMPILATION_IDENTIFIER = "lazy-compilation-proxy";
export declare const BROWSER_LOG_PREFIX = "[browser]";
