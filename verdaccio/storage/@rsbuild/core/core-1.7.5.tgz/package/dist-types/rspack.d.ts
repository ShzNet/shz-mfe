declare const rspack: (typeof import('@rspack/core'))['rspack'];
export { rspack };
