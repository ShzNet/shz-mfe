import type { Formatter } from './formatter';
import type { BabelCodeFrameOptions } from './types/babel__code-frame';
declare function createCodeFrameFormatter(options?: BabelCodeFrameOptions): Formatter;
export { createCodeFrameFormatter };
export type { BabelCodeFrameOptions };
