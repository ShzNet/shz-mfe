import type { Formatter, FormatterPathType } from './formatter';
declare function createRspackFormatter(formatter: Formatter, pathType: FormatterPathType): Formatter;
export { createRspackFormatter };
