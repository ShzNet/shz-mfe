interface IssuePosition {
    line: number;
    column: number;
}
declare function compareIssuePositions(positionA?: IssuePosition, positionB?: IssuePosition): number;
export { compareIssuePositions };
export type { IssuePosition };
