import type { FormatterPathType } from '../formatter';
import type { Issue } from './issue';
declare class IssueRspackError extends Error {
    readonly issue: Issue;
    readonly hideStack = true;
    file?: string;
    constructor(message: string, pathType: FormatterPathType, issue: Issue);
}
export { IssueRspackError };
