import type { ChildProcess } from 'node:child_process';
import type { RpcRemoteMethod } from './types';
export declare function wrapRpc<T extends (...args: any[]) => any>(childProcess: ChildProcess): RpcRemoteMethod<T>;
