declare const TYPESCRIPT_GO_PACKAGE = "@typescript/native-preview";
declare const TYPESCRIPT_GO_PACKAGE_JSON = "@typescript/native-preview/package.json";
declare const TYPESCRIPT_GO_ISSUE_CODE = "TSGO";
export { TYPESCRIPT_GO_PACKAGE, TYPESCRIPT_GO_PACKAGE_JSON, TYPESCRIPT_GO_ISSUE_CODE };
