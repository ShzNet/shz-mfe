import type { Issue, IssueDefaultSeverity } from '../issue';
import type { Logger } from '../logger';
import type { TypeScriptWorkerConfig } from './type-script-worker-config';
declare function resolveTypeScriptGoPackageJsonPath(config: TypeScriptWorkerConfig): string;
declare function resolveTypeScriptGoBinPath(config: TypeScriptWorkerConfig): Promise<string>;
declare function createTypeScriptGoArgs(config: TypeScriptWorkerConfig): string[];
declare function getTypeScriptGoErrorCount(output: string): number | undefined;
declare function parseTypeScriptGoIssues(output: string, config: TypeScriptWorkerConfig, defaultSeverity?: IssueDefaultSeverity): Issue[];
declare function createTypeScriptGoExitIssues(output: string, signal: NodeJS.Signals | null, config: TypeScriptWorkerConfig, defaultSeverity?: IssueDefaultSeverity): Issue[];
declare function isTypeScriptGoIssue(issue: Issue): boolean;
declare function isTypeScriptGoStatsError(error: unknown): boolean;
declare function runTypeScriptGo(config: TypeScriptWorkerConfig, logger: Pick<Logger, 'error'>, defaultSeverity?: IssueDefaultSeverity, signal?: AbortSignal): Promise<Issue[]>;
declare function getTypeScriptGoDependencies(config: TypeScriptWorkerConfig): {
    files: string[];
    dirs: string[];
    excluded: string[];
    extensions: string[];
};
export { createTypeScriptGoArgs, createTypeScriptGoExitIssues, getTypeScriptGoDependencies, getTypeScriptGoErrorCount, isTypeScriptGoIssue, isTypeScriptGoStatsError, parseTypeScriptGoIssues, resolveTypeScriptGoBinPath, resolveTypeScriptGoPackageJsonPath, runTypeScriptGo, };
