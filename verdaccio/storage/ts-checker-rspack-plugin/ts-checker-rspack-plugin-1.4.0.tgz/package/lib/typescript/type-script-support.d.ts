import type { TypeScriptWorkerConfig } from './type-script-worker-config';
declare function assertTypeScriptGoExecutable(config: TypeScriptWorkerConfig): Promise<void>;
declare function assertTypeScriptSupport(config: TypeScriptWorkerConfig): void;
export { assertTypeScriptGoExecutable, assertTypeScriptSupport };
